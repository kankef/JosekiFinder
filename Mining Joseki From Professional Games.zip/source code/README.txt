Felix Kanke
Joseki Finder

The source code contains of 4 files I wrote. I ran the program using python 3.6 on a Windows 10 machine. I used an external open source module
to parse sgf file which first needs to be installed on the system to run this application. The easiest method is using pip:

pip install sgf==0.5

If pip is not available, I included a copy of the module which I downloaded from https://github.com/jtauber/sgf. 
I DID NOT WRITE THIS MODULE. To install:

python setup.py install
──────────────────────────────────────────

Once the sgf parsing module is installed, to produce the SGF and p files run:

python .\main.py

This will yield the unpruned output files. I may not provide you with my main dataset of 89000 games. I purchased these and do not
have the rights for re-distribution. Instead I created a directory with a single short example game. The provided source code is hard coded
to search that directory for SGF files and produces the output. Once the unpruned output of the single file is created run:

python .\pruneTree.py

This creates the pruned and sorted output file. Since there is only one game the output will not actually do any pruning however it uses
the same code I used for a larger dataset.
──────────────────────────────────────────

To read the SGF output files it is unfortunately necessary to download an SGF reader. Since I am unsure which platform this will be tested
in I will simply provide links to options:

Windows

I recommend Drago - this one is easiest to use: http://www.godrago.net 
Comments and the massive tree will be visible on the side panel. To more clearly see all the variations please
navigate to options->options->Moves and in the Markup of Variations choose 'Uppercase Letters'
Loading the unpruned files could take a while.

Other Platforms

I am on Windows so I did not get to check the following application on other platforms
Sabaki is available for linux, mac, and windows - https://github.com/yishn/Sabaki/releases/tag/v0.31.5
To see my notes on the frequency navigate to View->Show Comments

I do not recommend opening the unpruned files using this editor. It took approximately 30 seconds to load on my machine.

Another option for all platforms is Kombilo - https://www.u-go.net/2016/kombilo084/
This is a more in depth tool for SGF files. Again I only use this on Windows. 
This tool is much faster at loading files but may be more cumbersome to install

──────────────────────────────────────────

Sorry for the inconvenience.
If there is trouble with reading the output file please contact me at my university email - kankef@myumanitoba.ca